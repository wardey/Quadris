#ifndef _INFO_H_
#define _INFO_H_
#include "Enums.h"
struct Info {
	int x, y;
	BlockType bt;
	int level;
};
#endif
