#ifndef _ENUMS_H_
#define _ENUMS_H_
enum class BlockType {IBlock, OBlock, TBlock, SBlock, ZBlock, LBlock, JBlock, OneBlock};
enum class Orientation { Up, Left, Down, Right };
#endif
